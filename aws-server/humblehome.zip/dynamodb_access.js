
// Load the AWS SDK for Node.js
var AWS = require('aws-sdk');
// Set the region
AWS.config.update({region: 'us-east-1'});

// Create DynamoDB service object
var ddb = new AWS.DynamoDB({apiVersion: '2011-12-05'});

var INFO_TABLE = 'humblehome-mobilehub-2128789566-Breakers';
var USER_ID = '48756d626c65486f6d65';

var DATA_TABLE = '';

module.exports = {
	
	getBreakerInfo: function (id) {
		
		var params = {
			TableName: INFO_TABLE,
			Key: {
				userId: USER_ID,
				breakerId: id
			}
		};
		
		ddb.getItem(params, function(error, result) {
			if (error) {
				console.log(error, error.stack);
			} else {
				console.log(result);
			}
		}
		
	}
	
	putBreakerData: function (data) {

		var params = {
			TableName: DATA_TABLE,
			// Table attributes here
		};
	
		ddb.putItem(params, function(error, result) {
			if (error) {
				console.log("Error", error);
			} else {
				console.log("Success, results);
			}
		}
	
	}
	
}