
var mqtt = require('mqtt');
var fs = require('fs');
var sleep = require('system-sleep');

var serverUri = "ssl://b-f6c789c3-b708-4d73-b004-2a6245bd7c5d-1.mq.us-east-1.amazonaws.com:8883";
var clientId = "test-client";
var username = "user";
var password = "humblehome1896";

var BreakerData = "BreakerData";

var client = mqtt.connect(serverUri, {
	clientId: clientId,
    username: username,
    password: password,
    rejectUnauthorized: false
});

var slayer = require('slayer');
var split = require('split');
    
client.on('connect', function(connack) {
    console.log('connected to ' + serverUri);
	
	// assume cmd = node test.js path\to\test\data\file
	fs.readFile(process.argv[2], function(error, data) {
		if (!error) {
			var loads = data.toString().split('\n');
			for (var i = 0; i < loads.length; i++) {
				console.log(loads[i]);
				client.publish(BreakerData, loads[i]);
				// Wait 5 seconds
				//sleep(5000);
				sleep(1000);
			}
		} else console.log('error: ' + error);
	});
});
    
client.on('reconnect', function() {
    console.log('reconnected to ' + serverUri);
});
   
client.on('error', function(error) {
    console.log('error: ' + error); 
});
    
client.on('message', function(topic, message) {
    console.log('topic: ' + topic + '\nmessage: ' + message);
});
